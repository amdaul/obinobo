/* =========================================================
   Zuma — rule-based FAQ assistant (no AI, fixed logic tree)
   ========================================================= */

(function(){

  const FAQ_ANSWERS = {
    price: "আমাদের দুইটা টায়ার আছে — Budget Box (৳১,৪৯০) ও Premium Box (৳২,৯৯০)। প্রতিটা বক্সের বিস্তারিত আইটেম লিস্ট Products পেজে পাবেন।",
    delivery: "ঢাকার ভিতরে সাধারণত ১-২ কর্মদিবসে ডেলিভারি হয়, ঢাকার বাইরে ৩-৫ কর্মদিবস লাগতে পারে। ডেলিভারি চার্জ এলাকাভেদে ৭০-১৫০ টাকা।",
    payment: "আমরা bKash, Nagad ও ক্যাশ অন ডেলিভারি (COD) — তিনটাই সাপোর্ট করি। অর্ডার কনফার্ম করার সময় আপনার পছন্দমতো পদ্ধতি বেছে নিতে পারবেন।",
    return: "প্রোডাক্ট পছন্দ না হলে রিটার্ন করা সম্ভব, তবে ডেলিভারি চার্জটা এক্ষেত্রে কাস্টমারকে বহন করতে হবে। বিস্তারিত জানতে কাস্টমার কেয়ারে যোগাযোগ করুন।"
  };

  let settings = null;
  let products = [];
  let waLink = "#";

  const els = {};

  function el(tag, cls, html){
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (html !== undefined) e.innerHTML = html;
    return e;
  }

  function addBotMessage(html){
    const msg = el('div', 'zuma-msg bot', html);
    els.body.appendChild(msg);
    scrollDown();
  }

  function addUserMessage(text){
    const msg = el('div', 'zuma-msg user', text);
    els.body.appendChild(msg);
    scrollDown();
  }

  function addOptions(options){
    const wrap = el('div', 'zuma-options');
    options.forEach(opt => {
      const btn = el('button', 'zuma-option-btn', opt.label);
      btn.addEventListener('click', () => {
        wrap.remove();
        addUserMessage(opt.label);
        opt.action();
      });
      wrap.appendChild(btn);
    });
    els.body.appendChild(wrap);
    scrollDown();
  }

  function scrollDown(){
    els.body.scrollTop = els.body.scrollHeight;
  }

  function showMainMenu(){
    addBotMessage("আমি কীভাবে সাহায্য করতে পারি?");
    addOptions([
      { label: "🎁 উপহার হিসেবে পাঠাতে চাই", action: askOccasion },
      { label: "🛍️ নিজের জন্য দেখতে চাই", action: () => showProducts(products) },
      { label: "❓ সাধারণ প্রশ্ন (দাম/ডেলিভারি/পেমেন্ট)", action: showFaqMenu },
    ]);
  }

  function askOccasion(){
    addBotMessage("খুব ভালো! এটা কোন উপলক্ষ্যে পাঠাচ্ছেন?");
    addOptions([
      { label: "🎂 জন্মদিন", action: () => showProducts(filterByOccasion('birthday'), 'birthday') },
      { label: "💍 বিবাহবার্ষিকী", action: () => showProducts(filterByOccasion('anniversary'), 'anniversary') },
      { label: "❤️ ভালোবাসা দিবস", action: () => showProducts(filterByOccasion('valentine'), 'valentine') },
      { label: "🎀 সাধারণ উপহার", action: () => showProducts(filterByOccasion('general'), 'general') },
    ]);
  }

  function filterByOccasion(tag){
    return products.filter(p => p.occasions.includes(tag));
  }

  function showProducts(list, occasionTag){
    if (!list.length){
      addBotMessage("এই উপলক্ষ্যের জন্য নির্দিষ্ট কোনো বক্স পাইনি, তবে আমাদের সবগুলো বক্সই যেকোনো উপলক্ষ্যে মানানসই:");
      list = products;
    } else if (occasionTag){
      const label = window.Obinobo ? window.Obinobo.OCCASION_LABELS[occasionTag] : occasionTag;
      addBotMessage(`${label}-র জন্য এই বক্সগুলো দারুণ মানাবে:`);
    } else {
      addBotMessage("আমাদের সব বক্স এখানে দেখুন:");
    }

    list.forEach(p => {
      const card = el('div', 'zuma-product-card');
      card.innerHTML = `
        <img src="${resolvePath(p.image)}" alt="${p.name}">
        <div class="zpc-info">
          <strong>${p.name}</strong>
          <span>${p.currency}${p.price.toLocaleString('en-US')}</span>
        </div>
      `;
      card.style.cursor = 'pointer';
      card.addEventListener('click', () => {
        window.location.href = resolvePath(`product.html?slug=${p.slug}`);
      });
      els.body.appendChild(card);
    });
    scrollDown();

    addOptions([
      { label: "❓ দাম/ডেলিভারি/পেমেন্ট জানতে চাই", action: showFaqMenu },
      { label: "⬅️ মেনুতে ফিরে যান", action: showMainMenu },
    ]);
  }

  function showFaqMenu(){
    addBotMessage("কোন বিষয়ে জানতে চান বেছে নিন:");
    addOptions([
      { label: "দাম", action: () => answerFaq('price') },
      { label: "ডেলিভারি সময়/চার্জ", action: () => answerFaq('delivery') },
      { label: "পেমেন্ট মেথড", action: () => answerFaq('payment') },
      { label: "রিটার্ন পলিসি", action: () => answerFaq('return') },
    ]);
    addOptions([
      { label: "⬅️ মেনুতে ফিরে যান", action: showMainMenu },
    ]);
  }

  function answerFaq(key){
    addBotMessage(FAQ_ANSWERS[key]);
    addOptions([
      { label: "❓ আরেকটা প্রশ্ন", action: showFaqMenu },
      { label: "👩‍💼 কাস্টমার কেয়ারে কথা বলুন", action: escalate },
      { label: "⬅️ মেনুতে ফিরে যান", action: showMainMenu },
    ]);
  }

  function escalate(){
    addBotMessage(`এই বিষয়ে সরাসরি আমাদের কাস্টমার কেয়ারে কথা বলুন। <br><a href="${waLink}" target="_blank" rel="noopener" class="btn btn-whatsapp" style="margin-top:8px;display:inline-flex;">WhatsApp-এ মেসেজ করুন</a>`);
    addOptions([
      { label: "⬅️ মেনুতে ফিরে যান", action: showMainMenu },
    ]);
  }

  function resolvePath(p){
    // adjust relative path depth based on current page location
    const depth = location.pathname.includes('/admin/') ? '../' : '';
    return depth + p;
  }

  async function boot(){
    if (!window.Obinobo) return;
    settings = await window.Obinobo.getSettings();
    try{
      products = await window.Obinobo.getProducts();
    }catch(e){ products = []; }
    waLink = window.Obinobo.buildWhatsAppLink(settings.whatsappNumber, "হাই Obinobo! আমার একটা প্রশ্ন আছে।");

    addBotMessage("হাই! আমি জুমা, আপনার ভার্চুয়াল অ্যাসিস্ট্যান্ট। কীভাবে সাহায্য করতে পারি?");
    showMainMenu();
  }

  function buildWidget(){
    const launcher = el('button', 'zuma-launcher');
    launcher.setAttribute('aria-label', 'জুমা চ্যাট সহায়ক খুলুন');
    launcher.innerHTML = `<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 12a8 8 0 1 1 3.2 6.4L4 20l1.2-3.6A7.96 7.96 0 0 1 4 12Z" stroke="white" stroke-width="1.8" stroke-linejoin="round"/><circle cx="9" cy="12" r="1" fill="white"/><circle cx="12.5" cy="12" r="1" fill="white"/><circle cx="16" cy="12" r="1" fill="white"/></svg>`;

    const win = el('div', 'zuma-window');
    win.innerHTML = `
      <div class="zuma-header">
        <div class="zuma-avatar">জ</div>
        <div>
          <div class="zuma-title">জুমা</div>
          <div class="zuma-sub">ভার্চুয়াল অ্যাসিস্ট্যান্ট • সাধারণত তাৎক্ষণিক উত্তর</div>
        </div>
        <button class="zuma-close" aria-label="বন্ধ করুন">✕</button>
      </div>
      <div class="zuma-body"></div>
    `;

    document.body.appendChild(launcher);
    document.body.appendChild(win);

    els.body = win.querySelector('.zuma-body');
    const closeBtn = win.querySelector('.zuma-close');

    let booted = false;
    launcher.addEventListener('click', () => {
      win.classList.toggle('open');
      if (win.classList.contains('open') && !booted){
        booted = true;
        boot();
      }
    });
    closeBtn.addEventListener('click', () => win.classList.remove('open'));
  }

  document.addEventListener('DOMContentLoaded', buildWidget);
})();
