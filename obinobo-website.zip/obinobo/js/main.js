/* =========================================================
   Obinobo — shared site scripts
   ========================================================= */

const Obinobo = (() => {

  const OCCASION_LABELS = {
    birthday: "জন্মদিন",
    anniversary: "বিবাহবার্ষিকী",
    valentine: "ভালোবাসা দিবস",
    general: "সাধারণ উপহার"
  };

  let settingsCache = null;
  let productsCache = null;
  let aboutCache = null;

  async function getSettings(){
    if (settingsCache) return settingsCache;
    try{
      const res = await fetch('data/settings.json');
      settingsCache = await res.json();
    }catch(e){
      settingsCache = { whatsappNumber: "8801XXXXXXXXX", metaPixelId: "", brandName: "Obinobo" };
    }
    return settingsCache;
  }

  async function getProducts(){
    if (productsCache) return productsCache;
    const res = await fetch('data/products.json');
    const data = await res.json();
    productsCache = data.products;
    return productsCache;
  }

  async function getAbout(){
    if (aboutCache) return aboutCache;
    const res = await fetch('data/about.json');
    aboutCache = await res.json();
    return aboutCache;
  }

  function money(product){
    return `${product.currency}${product.price.toLocaleString('en-US')}`;
  }

  function buildWhatsAppLink(number, message){
    const clean = (number || '').replace(/[^0-9]/g, '');
    return `https://wa.me/${clean}?text=${encodeURIComponent(message)}`;
  }

  async function whatsappOrderLink(product){
    const settings = await getSettings();
    const msg = `হাই Obinobo! আমি "${product.name}" (${money(product)}) অর্ডার করতে চাই।`;
    return buildWhatsAppLink(settings.whatsappNumber, msg);
  }

  async function injectPixel(){
    const settings = await getSettings();
    if (!settings.metaPixelId) return;
    /* eslint-disable */
    !function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
    n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
    document,'script','https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', settings.metaPixelId);
    fbq('track', 'PageView');
    /* eslint-enable */
  }

  function initNav(){
    const toggle = document.querySelector('.hamburger');
    const nav = document.querySelector('.main-nav');
    if (!toggle || !nav) return;
    toggle.addEventListener('click', () => {
      document.body.classList.toggle('nav-open');
    });
    nav.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => document.body.classList.remove('nav-open'));
    });
    // mark active link
    const path = location.pathname.split('/').pop() || 'index.html';
    nav.querySelectorAll('a[data-page]').forEach(a => {
      if (a.dataset.page === path) a.classList.add('active');
    });
  }

  function initReveal(){
    const els = document.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window)){
      els.forEach(el => el.classList.add('is-visible'));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting){
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    els.forEach(el => io.observe(el));
  }

  async function initStickyWhatsApp(){
    const link = document.querySelector('.sticky-whatsapp');
    if (!link) return;
    const settings = await getSettings();
    const msg = "হাই Obinobo! আমি একটা গিফট বক্স সম্পর্কে জানতে চাই।";
    link.href = buildWhatsAppLink(settings.whatsappNumber, msg);
  }

  function init(){
    initNav();
    initReveal();
    initStickyWhatsApp();
    injectPixel();
  }

  document.addEventListener('DOMContentLoaded', init);

  return {
    getSettings, getProducts, getAbout,
    money, buildWhatsAppLink, whatsappOrderLink,
    OCCASION_LABELS
  };
})();
